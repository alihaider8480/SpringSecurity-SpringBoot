package com.spring.springTest.Services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.spring.springTest.dto.UserDTO;
import com.spring.springTest.dto.UserDTOMapper;
import com.spring.springTest.repository.UserRepository2;

@Service
public class UserServies
{
	@Autowired
	UserRepository2 userRepository2; 

	// fetch all recode
	public List<UserDTO> findAll() 
	{  
		try 
		{
		  return userRepository2.findAll();
	    }
		catch(Exception e) 
		{
		 e.getMessage();
	    }
	   return null;
	}
	
	public int insert(UserDTO userDto)
	{
	
		try 
		{
		  return userRepository2.insertUser(userDto);
	    }
		catch(Exception e) 
		{
		 e.getMessage();
	    }
		return 0;
	}
	
	public int update(UserDTO userDto)
	{
	
		try 
		{
		  return userRepository2.updateUser(userDto);
	    }
		catch(Exception e) 
		{
		 e.getMessage();
	    }
		return 0;
	}
	
	public int delete(Long id)
	{
		try 
		{
		  return userRepository2.deleteUser(id);
	    }
		catch(Exception e) 
		{
		 e.getMessage();
	    }
		return 0;
	}
}












//@Override
//public int getAll(UserDTO tutorial) 
//{		
//  return jdbcTemplate.update("INSERT INTO test.test1 VALUES(?,?,?)",new Object[] { "6", "ali1", "c/161" });
//}