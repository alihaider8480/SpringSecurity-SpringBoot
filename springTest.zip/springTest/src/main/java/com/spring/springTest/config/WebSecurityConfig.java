package com.spring.springTest.config;

import javax.swing.text.PasswordView;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)                // ya agar ma method ka upar agar likha raha ho ka yahi methhod chala ga to iska lia mujha phala isko enable karna para ga
public class WebSecurityConfig extends WebSecurityConfigurerAdapter 
{

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		 http
		.authorizeRequests()
		.antMatchers("/login","/Contact").permitAll()       // in url ko ya public use kar sakta ha hum or is ma login ni manga ga
		//.antMatchers("/login","/Home0").hasRole("ADMIN")  // is sa sirf admin hi  home ko access hi kar sakta ha
		//.antMatchers("/login","/Home0").hasRole("NORMAL")  // is sa sirf view kar sakta hi  home ko access hi kar sakta ha
		//.antMatchers("/HomeController/**").permitAll()    // homecontroller ka andar jitna bhi request ae ho wo sub access kar sakta ha inka lia authenticaation ni hogi
		.anyRequest()
		.authenticated()
		.and()
		.httpBasic();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception 
	{
																	// yaha pa mana nicha wala method call kia ha
																	// or wo encode kar daga password ko
		auth.inMemoryAuthentication().withUser("simpaisa").password(this.passwodEncoder().encode("asdf")).roles("ADMIN");
	}
	
	@Bean
	public PasswordEncoder passwodEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	
// 		bean is lia lagaya ha taka kahi sa bhi access ho jae
//		@Bean
//		public PasswordEncoder passwodEncoder()
//		{
//			return NoOpPasswordEncoder.getInstance();
//		}
}