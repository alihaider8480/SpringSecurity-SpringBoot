package com.spring.springTest.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestingController 
{
	@GetMapping("/contact")
	public String contact()
	{
		return "Contact Page";
	}
	
	@GetMapping("/login")
	public String login()
	{
		return "Contact Page";
	}
}
